export class ChangePasswordDto{
    userId:number;
    password:string;
}