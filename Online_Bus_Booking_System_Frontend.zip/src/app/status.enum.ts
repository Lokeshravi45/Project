export enum Status {
    BOOKED=0,
    CANCELLED=1
}
