export class Wallet{
    cardName:string;
    cardNo:string;
    expMonth:number;
    expYear:number;
    cvv:number;
    amount:number;
}